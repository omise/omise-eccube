<?php
class plugin_update
{
    /**
     * @param  array               $plugin_info プラグイン情報
     * @param  SC_Plugin_Installer $installer   プラグインインストーラー
     *
     * @return void
     */
    public function update(array $plugin_info, SC_Plugin_Installer $installer)
    {
    }
}